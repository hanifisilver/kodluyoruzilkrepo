# -> başlık h1
## -> h2
### -> h3

- list item 1
- list item 2

* list item 3
* list item 4

*italic* **bold** ***italicbold***

[Google gitmek için buraya tıklayınız](https://google.com)

__________________________________________________________________________________________

 [lorem picsum](https://picsum.photos/200/300)

 ***

 '''
print("Hello Word")
 '''


